 ..........               .....         ......   .......... ..                                  ....
 .Z7ZZZZZZZ:.             .ZZ=..        .,Z=:.   .ZZZZZZZZZ~..                                  Z=~.
 $ZI7+~,.ZZI, .....     ...ZZ=,  .........Z=:.   .ZZ=,..ZZ=~..  ......   ....... .........   ...Z=~.
 .Z+.=ZZZ7?,.ZZ=,ZZ:. .ZZZZZZ=..ZZ7~:OZ~..Z=:.   .ZZZZZ$?7OZ,,.IZZ+~ZZ,..ZZ=~,ZZ:.ZZZZZZ~,..ZZZZZ=~.
 .Z7?+?+~...ZZZZZZ++.ZZII~.ZZ=...,ZZZZZ=..Z=:.   .ZZI=:,...Z?:ZZ7=,..Z=: .$ZZZZZ=.ZZ7?:+=.ZZ7+:.Z=~.
 .Z?=.     ZZ+~:.IZ:,Z=:..ZZZ=.ZZ+=,?ZZ=..Z=:.   .ZZ:...ZZZ7+.Z7:. .Z$?.ZZ+:,ZZZ~.ZZ=... Z?=..ZZZ=~.
 .ZZ=..    .ZZZZZ?7,.ZZZZ?+ZZ+.ZZZZ$+ZZ?.,Z?~    .ZZZZZ+??=,. .ZZZZZ7+,.ZZZZ?~ZZ=.ZZ+,   ZZZZ$I:ZZ=.
 .:~.      .,~==~, ..,~=~,.,~:.,~=~:.,~, .~:.    .,~~:,.....  .:~=~:. ..:==~,.::,.,~,.   .~=~:..::. 
               ...     .   .. .. ...     . .     .  ...                   . . .      .    . .   .   
           ... ......               ...           .....    ...........                              
           ZZ.$ZZZZ$,.              .Z::          .ZZ~.    IZ7ZZZZZZ,.                              
         ..ZZ???=,=Z+:  ....        .Z~~   .....  .ZZ=.    :Z++~,,ZZ+,    .....  ..    ...          
           ZZ,..ZZZ$=.~ZZZZZ,.  .?ZZZZ~~..ZZZZZZ:,.ZZ=.    :ZZZZZZZZZ.. .7ZZZZO..ZZ.  .ZZ~          
           ZZZZ?II=..Z$:~ZZZI: ZZII=.Z~~..:,:ZZZ=:.ZZ=.    :ZII+=~:.ZZ:.Z77~:.Z$~.,ZZZZ7I,          
           ZZ?~,. ..:Z++=~.Z:.Z$?,..ZZ~:.ZZ+=,OZ=:.ZZ~.    :Z~.  .$Z$7:ZZ+.  ?ZI:..ZZZZ..           
           ZZ=.    ..ZZZZZZI?.ZZZOZ$:ZI,ZZZZZ$IZ=:.ZZ=.    ZZZZZZ$II=..~ZZZZZ$7=.ZZII:.ZZ~.         
          .:+:.     .:=++?+,..,=+?=:,=+::=+?+~:++..~+~    .:+++=~,.    .:=++?~...:?~ ..,++.  


:::::::::::::::::::::::::::::::::::::DEVICE CONFIGURATION FILE:::::::::::::::::::::::::::::::::::::


For: Behringer V-Amp Series (V-Amp 2, V-Amp Pro, V-Ampire)
Format: rbs / syx(pic id=0)
Author: Durisian
Updates:


---Configuration Notes-----------------------------------------------------------------------------


Program Change Names: Default Titles (DT) / Hardware Location (HL)

Map 1: Post FX Mode
Map 2: Amplifier Type
Map 3: Cabinet Type
Map 4: Reverb Type
Map 5: Delay Type
Map 6: Pre Effect Type
Map 7: Noise Gate Level
Map 8: FX Type
Map 9: Digital Out
Map 10: Request Controls


---HELP--------------------------------------------------------------------------------------------

http://www.midibox.org/dokuwiki/doku.php?id=pedal_box

